from pandas.core.indexes.base import Index
from vosk import Model, KaldiRecognizer
import pyaudio
import pyttsx3
import pandas as pd
from ast import literal_eval
import datetime
import os

#Instantiating The Text To Speech Library
engine = pyttsx3.init()


#Initializing the Model
model = Model(r"C:\Users\David Erivona\Documents\Done\Done Projects\Project 1\model large")
recognizer = KaldiRecognizer(model, 16000)

#Recognize from the microfone

cap =pyaudio.PyAudio()
stream = cap.open(format=pyaudio.paInt16, channels=1, rate=16000, input=True,
frames_per_buffer=8192)
stream.start_stream()

df = pd.read_excel('questions.xlsx')
df2 = pd.read_excel('words.xlsx')
df3 = pd.read_excel('intro.xlsx')
df4 = pd.read_excel('s_words.xlsx')
df5 = pd.read_excel('Food.xlsx')

intro = 'Hi i am Davbob, how may i be of help?'
print(intro)
engine.say(intro)
engine.runAndWait()

while True:
    # engine = pyttsx3.init()
    data = stream.read(4096,exception_on_overflow = False)
    
    if recognizer.AcceptWaveform(data):
        result = recognizer.Result()
        result = literal_eval(result)
        # print('hi',result)
        result = result['text']
        print('Speaker :',result)

        ### NAMING BOT ###
        bot = 'David\'s Assistant :'
        ### INITIALIZING DATETIME ###
        now = datetime.datetime.now()   
        
        ### HOURS ###
        hours = now.strftime("%H")
        hours= int(hours)

        ### SECONDS ###
        seconds = now.strftime("%S")
        seconds= int(seconds)

        ### MINUTE ###
        minute = now.strftime("%M")
        minute= int(minute)

        ## FOOD ##
        #RICE_BOILING
        
        # def get_response(text):
        #     user_speech = [text]
        #     sentences = list(convo['Sentences']) + user_speech
        #     #     print (sentences)
        #     bag_of_words = TfidfVectorizer().fit_transform(sentences)
        #     similarity_scores = cosine_similarity(bag_of_words)
        #     similarity_scores = similarity_scores[-1][:-1]
        #     idx = np.argmax(similarity_scores)
        #     score = np.max(similarity_scores)
        #     if score >= 0.6:
        #         row = convo.iloc[idx]
        #         response = row['Responses']
        #     #intent = row['Intent']
        #     else:
        #         response = """I am sorry,I do not understand.Can you reword your statement. I am still undergoing training"""
        #     #         intent = None
        #     return (response)
        
        if 'music' in result:
            ans = 'Hope u enjoy'
            print(bot,ans)
            engine.say(ans)
            engine.runAndWait()
            os.startfile('music.mp3')
            
        if 'change your voice' in result:
            ans = 'how do you like this one'
            voices = engine.getProperty('voices')
            engine.setProperty('voice', voices[1].id)
            engine.say(ans)
            engine.runAndWait()

        # MORNING #
        if result == 'good morning':
            if hours >= 0 and hours <= 11:
                response = 'Good morning, how was your night ?'
                print(bot, response)
                engine.say(response)
                engine.runAndWait()
            else:
                say = ('It is no longer morning')
                print(bot, say)
                engine.say(say)
                engine.runAndWait()
                hours = now.strftime("%H")
                hours = int(hours)
                if hours > 11 and hours <= 16:
                    response = (f'It is afternoon, time is {now.strftime("%H:%M")}pm')
                    print(bot, response)
                    engine.say(response)
                    engine.runAndWait()
                elif hours > 16 and hours <= 23:
                    response = (f'It is evening, time is {now.strftime("%H:%M")}pm')
                    print(bot, response)
                    engine.say(response)
                    engine.runAndWait()

        # AFTERNOON #
        if result == 'good afternoon':
            if hours > 11 and hours <= 16:
                response = 'Good afternoon,how is your day going ?'
                print(bot, response)
                engine.say(response)
                engine.runAndWait()
            else:
                say = ('It is not afternoon')
                print(bot, say)
                engine.say(say)
                engine.runAndWait()
                hours = now.strftime("%H")
                hours = int(hours)
                if hours >= 0 and hours <= 11:
                    response = (f'It is morning, time is {now.strftime("%H:%M")}am')
                    print(bot, response)
                    engine.say(response)
                    engine.runAndWait()
                elif hours > 16 and hours <= 23:
                    response = (f'It is evening, time is {now.strftime("%H:%M")}pm')
                    print(bot, response)
                    engine.say(response)
                    engine.runAndWait()

        # EVENING #
        if result == 'good evening':
            if hours > 16 and hours <= 23:
                response = 'Good evening, how was your day ?'
                print(bot, response)
                engine.say(response)
                engine.runAndWait()
            else:
                say = ('It is not evening')
                print(bot, say)
                engine.say(say)
                engine.runAndWait()
                hours = now.strftime("%H")
                hours = int(hours)
                if hours >= 0 and hours <= 11:
                    response = (f'It is morning, time is {now.strftime("%H:%M")}am')
                    print(bot, response)
                    engine.say(response)
                    engine.runAndWait()
                elif hours > 11 and hours <= 16:
                    response = (f'It is afternoon, time is {now.strftime("%H:%M")}pm')
                    print(bot, response)
                    engine.say(response)
                    engine.runAndWait()
        if 'time' in result:
            ans = now.strftime('%H:%M:%S')
            print(bot, ans)
            engine.say(ans)
            engine.runAndWait()
        if 'date' in result:
            ans = now.strftime('%Y-%m-%d')
            print(bot, ans)
            engine.say(ans)
            engine.runAndWait()


        for i in df2['Words']:
            if i in result:
                ans = df2[df2['Words']==i]['Responses']
                ans = ans.iloc[0]
                print(bot,ans)
                engine.say(ans)
                engine.runAndWait()
        for i in df['Questions']:
            if i in result:
                ans = df[df['Questions']==i]['Responses']
                ans = ans.iloc[0]
                print(bot,ans)
                engine.say(ans)
                engine.runAndWait()
        
        
        for i in df3['Text']:
            if result == i:
                a = df3[df3['Text']==i]['Reply']
                a = a.iloc[0]
                print(bot,a)
                engine.say(a)
                engine.runAndWait()
                while True:
                    # engine = pyttsx3.init()
                    data = stream.read(4096,exception_on_overflow = False)
                    count = 0
                    if recognizer.AcceptWaveform(data):
                        result = recognizer.Result()
                        result = literal_eval(result)
                        result = result['text']
                        result = f'Hi {result} what can i do for you ?'
                        print(bot,result)
                        engine.say(result)
                        engine.runAndWait()
                        count = 1
                        break
        
        
        for i in df4['Word']:
            if result == i:
                ans = df4[df4['Word']==i]['Responses']
                ans = ans.iloc[0]
                print(bot,ans)
                engine.say(ans)
                engine.runAndWait()
        ### GREETINGS~SECTION ###


        if 'cook' in result or 'coop' in result:
            response = 'What do you want to cook ?'
            print(bot,response)
            engine.say(response)
            engine.runAndWait()
            while True:
                # engine = pyttsx3.init()
                data = stream.read(4096,exception_on_overflow = False)
                if recognizer.AcceptWaveform(data):
                    count = 0
                    result = recognizer.Result()
                    result = literal_eval(result)
                    result = result['text']
                    print('Speaker : ',result)
                    result = f'What type of {result}'
                    print(bot,result)
                    engine.say(result)
                    engine.runAndWait()
                    # count = 1
                    while True:
                        data = stream.read(4096,exception_on_overflow=False)
                        if recognizer.AcceptWaveform(data):
                            count=0
                            result = recognizer.Result()
                            result = literal_eval(result)
                            result = result['text']
                            for i in df5['Food']:
                                if result == i:
                                    ans = df5[df5['Food']==i]['Step']
                                    ans = ans.iloc[0]
                                    print('Speaker : ',result)
                                    print(bot,ans)
                                    engine.say(ans)
                                    engine.runAndWait()
                                    count=1
                                    break
                            break
                    break

