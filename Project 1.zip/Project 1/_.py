from vosk import Model, KaldiRecognizer
import pyaudio
import pyttsx3

engine = pyttsx3.init()
model = Model(r"C:\Users\David Erivona\Documents\New Project\model large")
recognizer = KaldiRecognizer(model, 16000)

#Recognize from the microfone

cap =pyaudio.PyAudio()
stream = cap.open(format=pyaudio.paInt16, channels=1, rate=16000, input=True,
frames_per_buffer=8192)
stream.start_stream()

while True:
    engine = pyttsx3.init()
    data = stream.read(4096,exception_on_overflow = False)
    if len(data) == 0:
        break
    if recognizer.AcceptWaveform(data):
        result = recognizer.Result()
        print(result)
        # voices = engine.getProperty('voices')
        # engine.setProperty('voice',voices[0].id)
        engine.say(result)
        engine.runAndWait()
        if result[''] == 'Bag':
            print('Shoe')
            engine.say('Shoe')
            engine.runAndWait()